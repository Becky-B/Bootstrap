$(document).ready(function(){
    $('.p1').hover(function(){
         var temp=$('.profile img').attr("data-alt-src");
         $('.profile img').attr("data-alt-src", $('.profile img').attr('src'));
         $('.profile img').attr('src', temp);
    });
    $('.p2').hover(function(){
        var temp=$('.profile img').attr("data-alt-src1");
        $('.profile img').attr("data-alt-src1", $('.profile img').attr('src'));
        $('.profile img').attr('src', temp);
   });
    $('.p3').hover(function(){
        var temp=$('.profile img').attr("data-alt-src2");
        $('.profile img').attr("data-alt-src2", $('.profile img').attr('src'));
        $('.profile img').attr('src', temp);
    });
})